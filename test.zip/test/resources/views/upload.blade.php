<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    @csrf
    @section('content')
<div class="header">文件上传</div>
    <form role="form" method="POST" action="" enctype="multipart/form-data">
    {{csrf_field()}}
    <div class="form-group">
        <label for="file">请选择文件</label><br/>
        <input id="file" type="file" name="file" class="@error('file') is-invalid @enderror"/>
        @error('file')
        <div class="alert alert-danger">{{ $message }}</div>
        @enderror
    </div>
    <div class="form-group">
        <button type="submit" value="确认上传">
            <i>确认上传</i>
        </button>
    </div>
</form>


    
</body>
</html>