<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    {{-- 报错显示在一起的写法 --}}
    {{-- @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $errors)
                    <li>{{$errors}}</li>
                @endforeach
            </ul> 

        </div>   
    @endif --}}
    <form action="test14" method="post">
        {{-- <input type="hidden" name="_token" value="{{csrf_token}}">以往的csrf写法 --}}
        @csrf
        姓名：<input type="text" name="name" value="" class="@error('name') is-invalid @enderror"><br/>

        @error('name')
        <div class="alert alert-danger">{{ $message }}</div>
        @enderror
        年龄：<input type="text" name="age" value=""class="@error('age') is-invalid @enderror"><br/>
        @error('age')
        <div class="alert alert-danger">{{ $message }}</div>
        @enderror
        邮箱：<input type="text" name="email" value=""class="@error('email') is-invalid @enderror"><br/>
        @error('email')
        <div class="alert alert-danger">{{ $message }}</div>
        @enderror
        <img src="{{captcha_src('flat')}}" onclick="this.src='/captcha/flat?'+Math.random()" title="点击图片重新获取验证码"><br/>
        验证码：<input type="text" name="captche" value=""class="@error('captche') is-invalid @enderror"><br/>
        @error('captche')
        <div class="alert alert-danger">{{ $message }}</div>
        @enderror
        <input type="submit" value="提交">
    </form>
    {{-- required 不能为空
    max：10 最大字符
    min：1 最小字符
    email:rfc,dns,stryct,spoof,filter 邮箱的合法性
    confirmed 验证两个字段是否相同
    Integer 验证字段必须为整形
    string 必须为字符串 
    nullable 可选字段
    distinct 验证数组时，指定的字段不能有任何重复值
    password:api 验证字段必须与当前登录用户的密码相同。你可以通过传入第一个参数来指定身份验证看守器（Authentication Guard）--}}
    
</body>
</html>
