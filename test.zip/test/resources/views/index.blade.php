<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="http://cdn.bootcss.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <style>
        table td,th{
            border: 1px solid #e5e5e5;
            padding: 20px;
        }
        .table{
            width: 100px;
            margin-left: 20px;
        }
    </style>
</head>
<body>
    <table style="border: 1px solid #000">
        <thead>
            <tr>
                <th>id</th>
                <th>name</th>
                <th>age</th>
                <th>email</th>
            </tr>
        </thead>
       
            @foreach ($list as $val)
        <tr>
            <td>{{$val->id}}</td>
            <td>{{$val->name}}</td>
            <td>{{$val->age}}</td>
            <td>{{$val->email}}</td>
        </tr>
            @endforeach
        
    </table>
    {{$list->links()}}
</body>
</html>