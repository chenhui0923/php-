<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php echo csrf_field(); ?>
    <?php $__env->startSection('content'); ?>
<div class="header">文件上传</div>
    <form role="form" method="POST" action="" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <label for="file">请选择文件</label><br/>
        <input id="file" type="file" name="file" class="<?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <button type="submit" value="确认上传">
            <i>确认上传</i>
        </button>
    </div>
</form>


    
</body>
</html><?php /**PATH D:\phpstudy_pro\WWW\phpxiangmu\test\resources\views/upload.blade.php ENDPATH**/ ?>