<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class car extends Model
{
    //数据表名 必须
    protected $table = 'user';
    // created_at   update_at禁用时间戳
    public $timestamps= false;

    public function cartest(){
      $int =  $this->insert([
            'name' => '小红',
            'age'  => '22',
            'email'=>'xiaohei@qq.com',
            ]);
        return $int;
    }
    public function cartest2(){
        return $this->get();
    }
    public function cartest3(){
        return $this->where('id','3')->update(['name'=>'小红']);
    }
    public function cartest4(){
        return $this->where('id','7')->delete();
    }

    public function fenye(){
        return $this->paginate(3);
    }

}
