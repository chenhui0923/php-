<?php

namespace App\Models\school;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Teacher extends Model
{
    protected $table = 'teacher as a';
    public $timestamps = false;

    //SELECT a.id,a.t_name,b.s_name FROM teacher AS a LEFT JOIN student AS b ON a.s_id=b.id
    public function index()
    {
        return $this->select('a.id', 'a.t_name', 'b.s_name')
            ->leftjoin('student as b', 'a.s_id', '=', 'b.id')
            ->get();
    }

    public function student()
    {
        return $this->hasOne('App\Models\school\Student', 'id', 's_id');
    }
    public function course()
    {
        return $this->hasMany('App\Models\Course', 't_id','id');
    }
    public function index1()
    {
        $data = $this->get();
        foreach ($data as $val) {
            echo $val->id . '&emsp;' . $val->t_name . '&emsp;' . $val->student->s_name . '<br/>';
        }
    }
    //yiduiduo
    public function index2()
    {
        $data = $this->get();
        foreach ($data as $val) {
            echo $val->id . '&emsp;' . $val->t_name . '&emsp;' . '<br/>';
            foreach ($val->course as $value) {
                echo $value->c_name . '<br/>';
            }
        }
    }
    //多对多
    public function realationship(){
        return $this->belongsToMany('App\Models\Course','realationship','t_id','c_id');
    }
    public function index3(){
        $data = $this->get();
        foreach($data as $val){
            echo '老师：'.$val->t_name.'&emsp;'.'<br/>'.'课程'.'&emsp;';
            foreach($val->realationship as $value){
                echo '&emsp;'.$value->c_name.'<br/>';
            }
        }
    }
    //获取一列数据
    public function lie(){
        $data = $this->pluck('t_name');
        foreach($data as $data){
            echo $data;
        }
    }
   
}
