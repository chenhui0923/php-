<?php

namespace App\Http\Controllers;

use Facade\FlareClient\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\car;
use App\Models\school\Teacher;
use Cache;
use Captcha;
use Session;



class TaskController extends Controller
{
    //测试
    public function test1(){
        return phpinfo();
    }

    //添加数据
   
    public function insert(){
        return DB::table('user')
            ->insert([
                'name'=>'小明',
                'age'=>'15',
                'email'=>'25135@qq.com',
                ]);
    }
    //修改数据
    public function update(){
        return DB::table('user')
            ->where('id','1')
            ->update(['name'=>'小刚']);
    }
    //查询数据
    public function select(){
       $list = DB::table('user')
            ->get();
          return View('index',compact('list'));
    }
    //删除数据
    public function delete(){
        return DB::table('user')
            ->where('id','2')
            ->delete();
    }
    
    //调用模型增加
    public function carinsert(){
        $model = new car();
        $list = $model->cartest();
        if($list>0){
            return View('index',compact('list'));
        }else{
            return '失败';
        }
    }
    //调用模型查询
    public function carselect(){
        $model = new car();
        $list = $model->cartest2();
        return View('index',compact('list'));
    }
    //调用修改
    public function carupdate(){
        $model = new car();
        $list = $model->cartest3();
        return $list;
    }
    //调用删除
    public function cardelete(){
        $model = new car();
        $list = $model->cartest4();
        return $list;
    }
    //调用分页方法
    public function fenye(){
        $model = new car();
        $list = $model->fenye();
        return View('index',compact('list'));
    }
    public function csrf(){
        return View('csrf');
    }

    //表单验证
    public function bdyz(Request $request){
        $this->validate($request,[
            'name'=>'required|min:2|max:30',
            'age'=>'required|min:1|max:130|integer',
            'email'=>'required|email',
            'captche'=>'required|captcha'
        ]);
        return View('csrf');
    }
    //获取请求方法  
    public function qqff(Request $request){
        $method = $request->method();
        echo $method;
    }
    //缓存
    //所有的缓存文件存放在storage\framework\cache\date
    public function huancun(){
        //put 设置缓存
        
            // Cache::put('Test1', '缓存文件', 5);
        
        //add 添加缓存,如果数据被成功添加到缓存返回true，否则返回false
        
            // dd(Cache::add('Test1','0', 100));
        
        //forever 永久缓存
            
            // Cache::forever('Test2', '缓存文件3');
        //获取缓存的方法,有就返回文件内容，没有就返回默认值default
        
            // $val=Cache::get('Test3', 'default');
            
        //forget 删除缓存

            // dd(Cache::forget('Test2'));删除永久缓存
            // dd(Cache::pull('Test1'));删除指定时间缓存
            // dd(Cache::flush());删除所有缓存

        //has 判断缓存是否存在
            
        //   dd(Cache::has('Test2'));
        
        //缓存自增
            
        //     $val =  Cache::increment('Test1', 1);
        //缓存递减
            // $dval= Cache::decrement('Test1', 2);
        
        Cache::remember('token', 20, function() {
            return 3 ;
        });
        
        return $dval;
    }
    public function lianbiao(){
        $model = new Teacher();
        $list = $model->index();
        $json = json_encode($list,JSON_UNESCAPED_UNICODE);
        return $json;
    }
    //session 缓存
    public function session(Request $request){
        //存储变量
        Session::put('key','小明');
        //获取变量
        $val= Session::get('key');
        //获取变量，没有则函数返回
        $val = Session::get('key1',function(){
            return 12346;
        });
        //获取Session的所有变量
        $val = Session::all();
        //判断Session是否存在，用户是否登入
        dd(
        $request->session()->has('key')
        );
        //删除变量
        
        $request->session()->forget('key');
        //删除所有变量
        
        $request->session()->flush();
        
        return $val;
    }

    //一对一
    public function yiduidyi(){
        $model = new Teacher();
        $list = $model->index1();
    }
    //一对多
    public function yiduiduo(){
        $model = new Teacher();
        $list = $model->index2();
        return $list;
    }
    //多对多
    public function duoduiduo(){
        $model = new Teacher();
        $list = $model->index3();
        return $list;
    }
    //获取一列数据
    public function lie(){
        $model = new Teacher();
        $list = $model->lie();
        return $list;
    }


}
