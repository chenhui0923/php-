<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use DB;
use Illuminate\Support\Facades\DB as FacadesDB;

class Foodseeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data=[
            [
            'f_name'=>'西瓜',
            'f_num'=>'20',
            'f_price'=>'5.4',
                ],
            [
                'f_name'=>'香蕉',
                'f_num'=>'10',
                'f_price'=>'6.4',
                ],
            [
            'f_name'=>'苹果',
            'f_num'=>'30',
            'f_price'=>'5',
            ],
    ];
        DB::table('food')->insert($data);
    }
}
