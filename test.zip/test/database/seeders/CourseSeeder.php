<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use DB;

class CourseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     * php artisan db:seed --class = Foodseeder
     *
     * @return void
     */
    public function run()
    {
        $data=[
            [
                'c_name'=>'语文',
                't_id'=>'1',
            ],
            [
                'c_name'=>'数学',
                't_id'=>'2',
            ],
        ];
        DB::table('course')->insert($data);
    }
}
