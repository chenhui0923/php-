<?php

use App\Http\Controllers\Admin;
use App\Http\Controllers\Home;
use App\Http\Controllers\Controller;
use App\Http\Controllers\TaskController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\StudentController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//http://blog.test/test2/?id=15
Route::get('/test2',function(){
    return "当前用户id". $_GET['id'];
})->name('nameid');//别名   终端查看所有路由别名  php artisan route:list 

//路由群组
Route::prefix('/group/group1')->group(function(){
    Route::get('/a',function(){return 'a';});
    Route::get('/b',function(){return 'b';});
});
//中间件  使用 first 和 second 中间件
Route::middleware(['first','second'])->group(function(){
    Route::get('/users',function(){});
    Route::get('users/profule', function($profule) {});
    
});
//必选参数
Route::get('/bixuan/{id}',function($id){
    echo '必选'.$id;
});
//可选参数
Route::get('kexuan/{id?}',function($id=''){
    echo '可选'.$id;
});

Route::get('/dog',[TaskController::class,'test1']);

Route::get('/admin/index',[Admin\IndexController::class,'index']);
Route::get('/home/index',[Home\IndexController::class,'index']);



Route::get('/insert',[TaskController::class,'insert']);
Route::get('/update',[TaskController::class,'update']);
Route::get('/select',[TaskController::class,'select']);
Route::get('/delete',[TaskController::class,'delete']);

//调用路由
Route::get('/index1',function(){
    return view('index');
});
//数组传值
Route::get('shuzu/{title?}',function($title='我是标题'){
    return view('index',['title'=>$title]);
});
//with传值
Route::get('with/{title?}',function($title='我是with标题'){
    return view('index')->with('title',$title);
});
//compact打包数组方式传值
Route::get('compact/{title?}',function($title='我是compact标题',$name='我是张三'){
    return view('index',compact('title','name'));
});

//判断视图文件是否存在
Route::get('test3',function(){
    if(View::exists('index')){
        echo '视图存在';
    }
    else{
        echo '视图不存在';
    }
});

//函数案例
Route::get('hanshu',function(){
    $time = strtotime(now());
    return View('index',compact('time'));
});

//model实例

Route::get('/test9', [TaskController::class,'carinsert']); 
Route::get('/test10',[TaskController::class,'carselect']);
Route::get('/test11',[TaskController::class,'carupdate']);
Route::get('/test12',[TaskController::class,'cardelete']);

//分页数据
Route::get('fenye',function(){
    return View('index');
});
Route::get('/fenye1',[TaskController::class,'fenye']);

Route::any('test13',[TaskController::class,'csrf']);

//表单验证
Route::any('test14',[TaskController::class,'bdyz']);
//文件上传
Route::any('upload',[StudentController::class,'upload']);
//获取请求方法
Route::any('qqff',[TaskController::class,'qqff']);
//缓存
Route::get('huancun',[TaskController::class,'huancun']);

//链表查询
Route::get('lianbiao',[TaskController::class,'lianbiao']);
//Session
Route::get('session',[TaskController::class,'session']);

//一对一关联
Route::get('yiduiyi',[TaskController::class,'yiduidyi']);
//一对多
Route::get('yiduiduo',[TaskController::class,'yiduiduo']);
//多对多
Route::get('duoduiduo',[TaskController::class,'duoduiduo']);
//获取一列数据
Route::get('lie',[TaskController::class,'lie']);
